//
//  CustomTableViewCell.swift
//  TestWorkAPP
//
//  Created by Mykhailo Romanovskyi on 02.12.2020.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    static let cellId = "CustomTableViewCell"
    
    private let cityNameLabel = UILabel()
    private let tempLabel = UILabel()
    private let emptyTextLabel = UILabel()
    private let conditionLabel = UILabel()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier )
        setupEmtpyLabel()
        setupMainElements()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func cleanCell() {
        emptyTextLabel.isHidden = false
        cityNameLabel.isHidden = true
        tempLabel.isHidden = true
        conditionLabel.isHidden = true
    }
    func setupCell(with data: DataModel) {
        emptyTextLabel.isHidden = true
        cityNameLabel.isHidden = false
        tempLabel.isHidden = false
        conditionLabel.isHidden = false
        
        cityNameLabel.text = data.geo_object?.locality?.name
        tempLabel.text = "\"\(data.fact?.temp ?? 0)\""
        conditionLabel.text = conditionParser(data: data.fact?.condition ?? "")
    }
    
    private func conditionParser(data: String) -> String {
        switch data {
        case "clear":
            return "Ясно"
        case "partly-cloudy":
            return  "Малооблачно"
        case "cloudy":
            return "Облачно с прояснениями"
        case "overcast":
            return "Пасмурно"
        case "drizzle":
            return "Морось"
        case "light-rain":
            return "Небольшой дожд"
        case "rain":
            return "Дождь"
        case "moderate-rain":
            return "Умеренно сильный дождь"
        case "heavy-rain":
            return "Сильный дождь"
        case "continuous-heavy-rain":
            return "Длительный сильный дождь"
        case "showers":
            return "Ливень"
        case "wet-snow":
            return "Дождь со снегом"
        case "light-snow":
            return "Небольшой снег"
        case "snow":
            return "Снег"
        case "":
            return ""
        case "snow-showers":
            return "снегопад"
        case "hail":
            return "град"
        case "thunderstorm":
            return "гроза"
        case "thunderstorm-with-rain":
            return "Дождь с грозой"
        case "thunderstorm-with-hail":
            return "Гроза с градом"
        default:
            return "Нет данных"
        }
    }
    
    private func setupEmtpyLabel() {
        addSubview(emptyTextLabel)
        emptyTextLabel.text = "Its empty now..."
        emptyTextLabel.font = UIFont(name: "Avenir-Light", size: 20)
        emptyTextLabel.textColor = .gray
        emptyTextLabel.textAlignment = .center
        
        emptyTextLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            emptyTextLabel.topAnchor.constraint(equalTo: topAnchor),
            emptyTextLabel.trailingAnchor.constraint(equalTo: trailingAnchor),
            emptyTextLabel.bottomAnchor.constraint(equalTo: bottomAnchor),
            emptyTextLabel.leadingAnchor.constraint(equalTo: leadingAnchor)
        ])
    }
    
    private func setupMainElements() {
        addSubview(cityNameLabel)
        addSubview(tempLabel)
        addSubview(conditionLabel)
        
        cityNameLabel.isHidden = true
        conditionLabel.isHidden = true
        tempLabel.isHidden = true
        
        cityNameLabel.font = UIFont(name: "Avenir-Light", size: 22)
        cityNameLabel.adjustsFontSizeToFitWidth = true
        cityNameLabel.textAlignment = .center

        tempLabel.font = UIFont(name: "Avenir-Light", size: 22)
        tempLabel.adjustsFontSizeToFitWidth = true
        tempLabel.textAlignment = .center

        conditionLabel.font = UIFont(name: "Avenir-Light", size: 22)
        conditionLabel.adjustsFontSizeToFitWidth = true
        conditionLabel.textAlignment = .right
        
        cityNameLabel.translatesAutoresizingMaskIntoConstraints = false
        conditionLabel.translatesAutoresizingMaskIntoConstraints = false
        tempLabel.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            cityNameLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
            cityNameLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            cityNameLabel.widthAnchor.constraint(equalToConstant: frame.width * 0.35),
            
            tempLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
            tempLabel.leadingAnchor.constraint(equalTo: cityNameLabel.trailingAnchor, constant: 20),
            tempLabel.widthAnchor.constraint(equalToConstant: frame.width * 0.2),
            
            conditionLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
            conditionLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -10),
            conditionLabel.widthAnchor.constraint(equalToConstant: frame.width * 0.40)
        ])
    }
}
