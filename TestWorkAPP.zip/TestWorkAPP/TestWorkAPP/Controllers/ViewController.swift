//
//  ViewController.swift
//  TestWorkAPP
//
//  Created by Mykhailo Romanovskyi on 02.12.2020.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    private var dataForTable = [DataModel]()
    private var cityes = [(Double,Double)]()
    private let numberOfCells = 10
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchData()
        setupMainElements()
    }
    
    @objc func addNewCity() {
        if dataForTable.count == numberOfCells {
            let alertController = UIAlertController(title: "Нет места", message: "Все ячейки занята, удалите минимум одну", preferredStyle: .alert)
            let action = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alertController.addAction(action)
            present(alertController, animated: true, completion: nil)
        } else {
            let vc = NewCoordinateViewController()
            vc.delegate = self
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .overCurrentContext
            present(vc, animated: true)
        }
    }
    private func setupMainElements() {
        title = "ПОГОДА"
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .add,
            target: self,
            action: #selector(addNewCity)
        )
        navigationItem.rightBarButtonItem?.isEnabled = false
        tableView.register(CustomTableViewCell.self, forCellReuseIdentifier: CustomTableViewCell.cellId)
        tableView.rowHeight = 60
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    private func fetchData() {
        cityes = setStartingData()
        for city in cityes {
            NetworkManager.shared.getdata(coorfinates: city) { (result) in
                switch result {
                case .success(let result):
                    DispatchQueue.main.async {
                        self.dataForTable.append(result)
                        self.navigationItem.rightBarButtonItem?.isEnabled = self.dataForTable.count == self.numberOfCells ? true : false
                        self.tableView.reloadData()
                    }
                case .failure(let error):
                    DispatchQueue.main.async {
                        print(error.localizedDescription)
                    }
                }
            }
        }
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        numberOfCells
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CustomTableViewCell.cellId, for: indexPath) as! CustomTableViewCell
        if indexPath.row < dataForTable.count {
            cell.setupCell(with: dataForTable[indexPath.row])
            return cell
        } else {
            cell.cleanCell()
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let storyboard = UIStoryboard(name: "DetailViewController", bundle: Bundle.main)
        guard let vc = storyboard.instantiateViewController(identifier: "DetailViewController") as? DetailViewController else { return }
        vc.dataForDisplay = dataForTable[indexPath.row]
        navigationController?.pushViewController(vc, animated: true )
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            tableView.beginUpdates()
            if indexPath.row < dataForTable.count {
                dataForTable.remove(at: indexPath.row)
            }
            let cell = tableView.cellForRow(at: indexPath) as! CustomTableViewCell
            cell.cleanCell()
            tableView.endUpdates()
            tableView.reloadData()
        }
    }
}

extension ViewController: NewCoordinateViewControllerProtocol {
    
    func viewController(didPassedData newCoor: (Double, Double)) {
        NetworkManager.shared.getdata(coorfinates: newCoor) { (result) in
            switch result {
            case .success(let result):
                DispatchQueue.main.async {
                    self.dataForTable.append(result)
                    self.tableView.reloadData()
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    print(error.localizedDescription)
                }
            }
        }
    }
}

extension ViewController {
    //Создадим метод для заполнения данными первоночальными
    func setStartingData() -> [(Double, Double)] {
        var data = [(Double, Double)]()
        data.append((55.752220, 37.615560))
        data.append((59.939095, 30.315868))
        data.append((55.030199, 82.920430))
        data.append((62.03389, 129.73306))
        data.append((48.51578, 135.10117))
        data.append((43.11981, 131.88692))
        data.append((43.60281, 39.73415))
        data.append((57.1613, 65.52502))
        data.append((51.6755, 39.20888))
        data.append((46.3588, 48.05993))
        return data
    }
}
