//
//  DetailViewController.swift
//  TestWorkAPP
//
//  Created by Mykhailo Romanovskyi on 04.12.2020.
//

import UIKit

class DetailViewController: UIViewController {
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var temp: UILabel!
    @IBOutlet weak var feelsLike: UILabel!
    @IBOutlet weak var humidity: UILabel!
    
    var dataForDisplay: DataModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupData(with: dataForDisplay)
    }
    
    private func setupData(with data: DataModel) {
        cityLabel.text = data.geo_object?.locality?.name
        dateLabel.text = "Сегодня: \(dateFormater(date: data.now_dt) ?? "ошибка")"
        
        if let temp = data.fact?.temp {
            self.temp.text = "Температура: \(temp)"
        }
        
        if let feelsTemp = data.fact?.feels_like {
            self.feelsLike.text = "Ощущается на: \(feelsTemp)"
        }
        
        if let humidity = data.fact?.humidity {
            self.humidity.text = "Влажность: \(humidity)%"
        }
    }
    
    private func dateFormater(date: String?) -> String? {
        guard let date = date  else { return nil}
        let dataFormater = DateFormatter()
        dataFormater.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        guard let dateObj = dataFormater.date(from: date) else { return nil }
        dataFormater.dateFormat = "dd-MM-YYYY"
        return dataFormater.string(from: dateObj)
    }
}



