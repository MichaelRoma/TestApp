//
//  NewCoordinateViewController.swift
//  TestWorkAPP
//
//  Created by Mykhailo Romanovskyi on 04.12.2020.
//
protocol NewCoordinateViewControllerProtocol: class {
    //  func viewController(_ viewController: NewCoordinateViewController, didPassedData newCoor: (Double, Double))
    func viewController(didPassedData newCoor: (Double, Double))
}

import UIKit

class NewCoordinateViewController: UIViewController {
    
    @IBOutlet weak var backGroundView: UIView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var latTextField: UITextField!
    @IBOutlet weak var lonTextField: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var cancelButton: UIButton!
    
    weak var delegate: NewCoordinateViewControllerProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let closeTap = UITapGestureRecognizer(target: self, action: #selector(closeTapGesture(_:)))
        backGroundView.addGestureRecognizer(closeTap)
        visualSetup()
    }
    
    @IBAction func saveButtoAction(_ sender: UIButton) {
        
        var lat: Double
        var lon: Double
        
        if latTextField.text?.isEmpty ?? true || lonTextField.text?.isEmpty ?? true{
            locaAlert(title: "Не хвататет данынх", message: "Одно из полей не заполненно")
            return
        }
        if latTextField.text?.last == " " {
            latTextField.text?.removeLast()
        }
        
        if lonTextField.text?.last == " " {
            lonTextField.text?.removeLast()
        }
        
        if let latFromString = Double(latTextField.text ?? ""), let lonFromString = Double(lonTextField.text ?? "") {
            lat = latFromString
            lon = lonFromString
        } else {
            locaAlert(title: "Не верный ввод", message: "Введите координаты заново и внимательеней")
            return
        }
        
        if lat > 90 || lon > 180 {
            locaAlert(title: "Не верный ввод", message: "Введите координаты заново, долгота не должна привышать 90, а долгота 180")
            return
        }
        
        delegate?.viewController(didPassedData: (lat, lon))
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func cancelButtonAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @objc func closeTapGesture (_ recognizer: UITapGestureRecognizer) {
        dismiss(animated: true, completion: nil)
    }
    
    @objc private func keyboardDismiss() {
        view.endEditing(true)
    }
    
    private func visualSetup() {
        mainView.layer.cornerRadius = 10
        saveButton.layer.cornerRadius = 10
        cancelButton.layer.cornerRadius = 10
        
        latTextField.inputAccessoryView = createToolBar()
        lonTextField.inputAccessoryView = createToolBar()
    }
    
    private func createToolBar() -> UIToolbar {
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(keyboardDismiss))
        toolBar.setItems([doneButton], animated: true)
        toolBar.isUserInteractionEnabled = true
        return toolBar
    }
    
    private func locaAlert(title: String?, message: String?) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok", style: .default, handler: nil)
        alertController.addAction(action)
        present(alertController, animated: true, completion: nil)
    }
}
