//
//  DataModel.swift
//  TestWorkAPP
//
//  Created by Mykhailo Romanovskyi on 02.12.2020.
//

struct DataModel: Codable {
    let now_dt: String?
    let geo_object: Geo_object?
    let fact: Fact?
    
    struct Geo_object: Codable {
        let locality: Locality?
        let country: Country?
        
        struct Locality: Codable {
            let name: String?
        }
        
        struct Country: Codable {
            let name: String?
        }
    }
    
    struct Fact: Codable {
        let temp: Int?
        let feels_like: Int?
        let humidity: Int?
        let condition: String?
    }
}

