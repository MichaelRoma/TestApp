//
//  NetworkManager.swift
//  TestWorkAPP
//
//  Created by Mykhailo Romanovskyi on 02.12.2020.
//
import Foundation

class NetworkManager {
    
    static let shared = NetworkManager()
    private init() {}
    
    private let key = "de5ac54f-6ce6-4b41-bf5a-ef43bcfa7b44"
    private let scheme = "https"
    private let host = "api.weather.yandex.ru"
    private let path = "/v2/forecast"
    
    func getdata(coorfinates: (Double, Double), completion: @escaping (Result<DataModel, Error>) -> Void) {
        guard let request = getUrlRequest(coorfinates: coorfinates) else { return }
        
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            if let error = error {
                completion(.failure(error))
            }
            
            if let response = response as? HTTPURLResponse, response.statusCode == 200 {
                if let data = data {
                    do {
                        let weatherData = try JSONDecoder().decode(DataModel.self, from: data)
                        completion(.success(weatherData))
                    } catch let error {
                        completion(.failure(error))
                    }
                }
            }
        }.resume()
    }
    
    private func getUrlRequest(coorfinates: (Double, Double)) -> URLRequest? {
        var urlComponents = URLComponents()
        urlComponents.scheme = scheme
        urlComponents.host = host
        urlComponents.path = path
        urlComponents.queryItems = [
            URLQueryItem(name: "lat", value: "\(coorfinates.0)"),
            URLQueryItem(name: "lon", value: "\(coorfinates.1)")
        ]
        
        guard let url = urlComponents.url else { return nil }
        var request = URLRequest(url: url)
        request.allHTTPHeaderFields = ["X-Yandex-API-Key":key]
        request.httpMethod = "GET"
        return request
    }
}
